<br>
<br>
<footer>
    <div class="container text-center">
        <a href="https://vk.com/kri_ip"><img src="/To-do-listAgressive/view/resources/image/vk.png" alt="VK" height="40" width="40"></a>
        <img src="/To-do-listAgressive/view/resources/image/telegram.png" alt="Telegram" height="40" width="40">
        <a href="mailto:novel.39.con@gmail.com"><img src="/To-do-listAgressive/view/resources/image/gmail.png" alt="VK" height="40" width="40"></a>
    </div>
</footer>

</body>

</html>